import React from 'react'

export default function Users() {
  return (
    <div><h1>Users</h1></div>
  )
}
