import React from 'react'

export default function Salesexpenses() {
  return (
    <div className='expense'>
    <h1>Sale Expense Table</h1>
  <div className="container">

    <div className="row">
      <table>
        <thead>
          <tr>

        <th>Date</th>	
        <th>Customer Name	</th>
        <th>Mobile No</th>	
        <th>Total Price	</th>
        <th>Total GST</th>
        <th>Overall Subtotal	</th>
        <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td>  
              <button className="btn btn-primary me-2">Edit</button>
            <button className="btn btn-danger">Delete</button></td>
          </tr>
        </tbody>
      </table>
      <hr/>
      <h2>Total Overall Subtotal: <label></label></h2>
    </div>
  </div>
</div>
  )
}
