import axios from 'axios';
import React, { useEffect, useState } from 'react'

export default function Sales() {



  const[newData, setNewData]= useState([]);
  const[id, setId]= useState();

  const[rows, setRows]= useState([{quantity:1}]);
  const[data, setData]= useState("")
  const[personaldata, setpersonaldata]= useState({
    date:"",
    customer:"",
    mobileno:""
  })

const handeladd=()=>{
  let copyrow = [...rows]
  copyrow.push({quantity:1})
  setRows(copyrow)
  console.log(rows);
}

function loadData() {
  axios.get("https://65d86bd0c96fbb24c1bb7cbe.mockapi.io/saleproject")
    .then((res) => {
      setNewData(res.data)
    })
  console.log(newData);
};
useEffect(() => {
  loadData();
}, [])


  return (
    <div className='salespage'>
      <div className="container">
        <div className="row">
          <div className="col-lg-4">
            <label className="form-label"> Date</label> <br />
            <input type="date" className="form-control"/>
          </div>
          <div className="col-lg-4">
            <label className="form-label"> Customer Name: </label> <br />
            <input type="text" className='form-control'/></div>
          <div className="col-lg-4">
          <label className="form-label"> Mobile No: </label> <br />
            <input type="text" className='form-control'/>
          </div>
        </div>

        <button className='btn btn-primary mt-2 mb-2' onClick={(()=>handeladd())}>Add Row</button>

        <div className="row">

        </div>
      </div>
      <div className="container">
        <table width="100%">
          <thead>
            <tr>
              <th>Product</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>GST</th>
              <th>Subtotal</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((rows)=>{

            return(
            <tr>
              <td><select class="form-select" aria-label="Default select example">
              <option selected>Select a Product</option>
              {newData.map((eachData,i)=>{
                return(
                  <option value="1">{eachData.product}</option>
                  

                )
              })}
              </select> </td>
              <td><label htmlFor=""></label></td>
              <td><input type="number" className='form-control' /></td>
              <td></td>
              <td></td>
              
              <td><button className='btn btn-danger'>Remove</button></td>
            </tr>
            )
})}
          </tbody>
        </table>
        <hr />
        <div class="mt-5">
          <h4>Total Price: 100.00</h4>
          <h4>Total GST: 18.00</h4>
          <h4>Overall Subtotal: 118.00</h4>
          </div>

          <div class="col-lg-12 d-flex justify-content-end"><button class="btn btn-success">Submit Data</button></div>
      </div>
    </div>
    
    

    
  )
}
